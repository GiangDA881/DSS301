package g2.g2_gp_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Dss301Application {

    public static void main(String[] args) {
        SpringApplication.run(Dss301Application.class, args);
    }

}
