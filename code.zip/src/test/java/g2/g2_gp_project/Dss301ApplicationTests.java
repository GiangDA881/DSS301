package g2.g2_gp_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Dss301ApplicationTests {

    @Test
    void contextLoads() {
    }

}
